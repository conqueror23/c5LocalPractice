<?php   defined('C5_EXECUTE') or die(_("Access Denied.")); ?>

<div class="alert alert-danger">
   <?php  echo t('<strong>Attention!</strong> Clearing your site\'s content prior to installing this theme is highly recommended.')?>
</div>