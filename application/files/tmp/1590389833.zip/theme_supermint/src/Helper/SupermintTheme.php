<?php
namespace Concrete\Package\ThemeSupermint\Src\Helper;


defined('C5_EXECUTE') or die(_("Access Denied."));

/**
 * @package Supermint theme Options
 * @category Helper
 * @author Sebastien Jacqmin <seb@tellthem.eu>
 * @copyright  Copyright (c) 2011-2012 myconcretelab (http://www.myconcretelab.com)
 * @license    http://www.concrete5.org/license/     MIT License
 */
use stdClass;
use \Concrete\Package\ThemeSupermint\Src\Models\ThemeSupermintOptions;
use Package;
use Loader;

class SupermintTheme {


}
