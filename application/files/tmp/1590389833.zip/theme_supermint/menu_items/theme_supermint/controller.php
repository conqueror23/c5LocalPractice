<?php 
namespace Concrete\Package\ThemeSupermint\MenuItem\ThemeSupermint;

use Concrete\Core\Application\UserInterface\Menu\Item\Controller as MenuItemController;

class Controller extends MenuItemController
{
}